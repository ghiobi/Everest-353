<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1>Have a conversation in real time.</h1>
            <p class="lead">Be happy.</p>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h3>Your conversations.</h3>
                <?php if(count($conversations) > 0): ?>
                    <ul class="list-group">
                        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li class="list-group-item">
                                <a href="/conversation/<?php echo e($conversation->id); ?>">With ->
                                <?php $__currentLoopData = $conversation->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if(Auth::user()->id != $user->id): ?>
                                        <?php echo e($user->fullName()); ?>.
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>
                <?php else: ?>
                    <div class="section text-xs-center">
                        <h3>No conversations.</h3>
                        <p class="lead mb-0">Make a conversations now! <i class="fa fa-arrow-circle-o-right"></i></p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <h4>Create a conversation with...</h4>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                <?php endif; ?>
                <form action="/conversation" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="">Select a person!</label>
                        <select name="with" id="" class="form-control">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php if(Auth::user()->id != $user->id): ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->fullName()); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </select>
                    </div>
                    <button class="btn btn-outline-primary btn-block" type="submit">Make Chat!</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>