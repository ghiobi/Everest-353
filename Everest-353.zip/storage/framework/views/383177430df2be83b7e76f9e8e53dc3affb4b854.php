<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1>Posts</h1>
            <p class="lead">Manage Posts</p>
        </div>
    </div>
    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th>
                        Name
                    </th>
                    <th>
                        Types
                    </th>
                    <th>
                        Comments Count
                    </th>
                    <th>
                        Start Postal Code
                    </th>
                    <th>
                        End Postal Code
                    </th>
                    <th>
                        Created At
                    </th>
                    <th>
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php if(count($posts) > 0): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td>
                            <a href="/post/<?php echo e($post->id); ?>"><?php echo e($post->name); ?></a>
                        </td>
                        <td>
                            <div class="tag tag-default tag-trip"><?php echo e(($post->postable_type == \App\LocalTrip::class)? 'Local' : 'Long Distance'); ?></div>
                            <div class="tag tag-info"><?php echo e(($post->one_time)? 'One Time' : 'Frequent'); ?></div>
                        </td>
                        <td>
                            <?php echo e(count($post->messages)); ?>

                        </td>
                        <td>
                            <?php echo e($post->departure_pcode); ?>

                        </td>
                        <td>
                            <?php echo e($post->destination_pcode); ?>

                        </td>
                        <td>
                            <?php echo e($post->created_at); ?>

                        </td>
                        <td>
                            <a href="/post/<?php echo e($post->id); ?>/edit" class="btn btn-warning btn-sm">Edit</a>
                            <a href="#" class="delete d-inline btn btn-sm btn-outline-danger"><i class="fa fa-trash"></i> Delete</a>
                            <form action="/post/<?php echo e($post->id); ?>/" method="post" style="display: none">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('delete')); ?>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php else: ?>
                <tr class="text-xs-center">
                    <td colspan="6">
                        <div class="section">
                            <h4>No Posts... <i class="fa fa-frown-o"></i></h4>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>