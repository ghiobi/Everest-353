<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <a href="/user/<?php echo e($user->id); ?>">Back to profile.</a>
            <h1 class="display-4">Your Profile</h1>
            <p class="lead">Show your true self!</p>
        </div>
    </div>
    <div class="container section">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-9">
                <h3 class="mb-1">Profile info</h3>
                <form action="<?php echo e(route('user.update', ['user' => $user->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <input type="hidden" name="_request" value="profile">
                    <div class="form-group row<?php echo e(($errors->has('first_name'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__first_name">First Name</label>
                        <div class="col-xs-10">
                            <input class="form-control" id="form__first_name" type="text" value="<?php echo e($user->first_name); ?>" name="first_name" required maxlength="255">
                            <?php if($errors->has('first_name')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('first_name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('last_name'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__last_name">Last Name</label>
                        <div class="col-xs-10">
                            <input class="form-control" id="form__last_name" type="text" value="<?php echo e($user->last_name); ?>" name="last_name" required maxlength="255">
                            <?php if($errors->has('last_name')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('last_name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('timezone'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__timezone">Tiemzone</label>
                        <div class="col-xs-10">
                            <input class="form-control" id="form__timezone" type="text" value="<?php echo e($user->timezone); ?>" name="timezone" required>
                            <?php if($errors->has('timezone')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('timezone')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('birth_date'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__birth_date">Brithday</label>
                        <div class="col-xs-10">
                            <div class="input-group">
                                <input class="form-control" id="form__birth_date" type="date" value="<?php echo e(($user->birth_date)? $user->birth_date->format('Y-m-d') : ''); ?>" name="birth_date">
                                <span class="input-group-addon">
                                    <input type="hidden" name="is_visible_birth_date" value="0">
                                    <input type="checkbox" name="is_visible_birth_date" <?php echo e(($user->is_visible_birth_date)? 'checked' : ''); ?> value="1">
                                </span>
                            </div>
                            <small class="form-control-feedback">
                                (YYYY-MM-DD)
                            </small>
                            <?php if($errors->has('birth_date')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('birth_date')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('address'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__address">Address</label>
                        <div class="col-xs-10">
                            <div class="input-group">
                                <input class="form-control" id="form__address" type="text" value="<?php echo e($user->address); ?>" name="address">
                                <span class="input-group-addon">
                                    <input type="hidden" name="is_visible_address" value="0">
                                    <input type="checkbox" name="is_visible_address" <?php echo e(($user->is_visible_address)? 'checked' : ''); ?>  value="1">
                                </span>
                            </div>
                            <?php if($errors->has('address')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('address')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('license_num'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__license_num">Licence Number</label>
                        <div class="col-xs-10">
                            <div class="input-group">
                                <input class="form-control" id="form__license_num" type="text" value="<?php echo e($user->license_num); ?>" name="license_num">
                                <span class="input-group-addon">
                                    <input type="hidden" name="is_visible_license_num" value="0">
                                    <input type="checkbox" name="is_visible_license_num" <?php echo e(($user->is_visible_license_num)? 'checked' : ''); ?> value="1">
                                </span>
                            </div>
                            <?php if($errors->has('license_num')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('license_num')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('policies'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__policies">Policies</label>
                        <div class="col-xs-10">
                            <div class="input-group">
                                <input class="form-control" id="form__policies" type="text" value="<?php echo e((empty($user->policies))? '' : implode(';', $user->policies)); ?>" name="policies">
                                <span class="input-group-addon">
                                    <input type="hidden" name="is_visible_policies" value="0">
                                    <input type="checkbox" name="is_visible_policies" <?php echo e(($user->is_visible_policies)? 'checked' : ''); ?> value="1">
                                </span>
                            </div>
                            <small class="form-control-feedback">
                                Separate your policies by a semicolon.
                            </small>
                            <?php if($errors->has('policies')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('policies')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('external_email'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__external_email">External Email</label>
                        <div class="col-xs-10">
                            <div class="input-group">
                                <input class="form-control" id="form__external_email" type="text" value="<?php echo e($user->external_email); ?>" name="external_email">
                                <span class="input-group-addon">
                                    <input type="hidden" name="is_visible_external_email" value="0">
                                    <input type="checkbox" name="is_visible_external_email" <?php echo e(($user->is_visible_external_email)? 'checked' : ''); ?> value="1">
                                </span>
                            </div>
                            <?php if($errors->has('external_email')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('external_email')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row<?php echo e(($errors->has('avatar'))? ' has-danger' : ''); ?>">
                        <label class="col-xs-2 col-form-label" for="form__avatar">Avatar</label>
                        <div class="col-xs-10">
                            <input type="file" id="form__avatar" accept="image/*" name="avatar">
                            <div class="form-control-feedback">
                                <?php if($user->avatar): ?>
                                    <img src="<?php echo e(url('images/' . $user->avatar . '?w=90')); ?>" alt="">
                                <?php endif; ?>
                                <span>Optional, 300 by 300 minimum, 5MB max</span>
                            </div>
                            <?php if($errors->has('avatar')): ?>
                                <span class="form-control-feedback"><?php echo e($errors->first('avatar')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="clearfix">
                        <button class="btn btn-primary float-xs-right" type="submit">Update!</button>
                    </div>
                </form>
                <h3 class="mt-2 mb-1">Change Password</h3>
                <form action="<?php echo e(route('user.update', ['user' => $user->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <input type="hidden" name="_request" value="password">
                    <div class="form-group row">
                        <label class="col-xs-2 col-form-label">Password</label>
                        <div class="col-xs-10">
                            <input class="form-control" type="password" name="password" required minlength="6" maxlength="255">
                        </div>
                        <small class="form-control-feedback">
                            minimum length of 6
                        </small>
                    </div>
                    <div class="form-group row">
                        <label class="col-xs-2 col-form-label">Confirm</label>
                        <div class="col-xs-10">
                            <input class="form-control" type="password" name="password_confirmation" required minlength="6" maxlength="255">
                        </div>
                    </div>
                    <div class="clearfix">
                        <button class="btn btn-primary float-xs-right" type="submit">Change!</button>
                    </div>
                </form>
                <?php if(Auth::user()->hasRole('admin')): ?>
                    <h3><?php echo e(($user->is_suspended)? 'Unsuspend' : 'Suspend'); ?></h3>
                    <p class="lead">Suspending the user will prevent the user form logging in.</p>
                    <form action="/user/<?php echo e($user->id); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('patch')); ?>

                        <input type="hidden" name="_request" value="suspend">
                        <button class="btn btn-warning"><?php echo e(($user->is_suspended)? 'Unsuspend' : 'Suspend'); ?></button>
                    </form>
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <h3>Need Help?</h3>
                <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A architecto, corporis dignissimos eaque eius, et facere impedit ipsam laudantium molestias natus quam sunt totam vel veritatis! Doloribus ex quod ut.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>