<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1 class="display-4">
                Mail Inbox
            </h1>
            <p class="lead">Get cracking with people!</p>
        </div>
    </div>
    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item active">Mail Inbox</li>
            <li class="breadcrumb-item"><a href="/mail/sent">Mail Sent</a></li>
            <li class="breadcrumb-item"><a href="/mail/compose">Compose Message</a></li>
        </ol>
        <table class="table">
            <thead>
                <tr>
                    <th>Sender</th>
                    <th>Message</th>
                    <th>Actions</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($messages) > 0): ?>
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e($message->sender->avatarUrl(30)); ?>" width="35" class="img-fluid rounded-circle" alt=""> <?php echo e($message->sender->fullName()); ?>

                            </td>
                            <td>
                                <?php echo $message->body; ?>

                            </td>
                            <td>
                                <a href="/mail/compose?recipient_id=<?php echo e($message->sender->id); ?>" title="reply"><i class="fa fa-reply"></i></a>
                            </td>
                            <td>
                                <?php echo e($message->created_at->diffForHumans()); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php else: ?>
                    <tr class="text-xs-center">
                        <td colspan="4">
                            <div class="section">
                                <h4>Have no message? <i class="fa fa-frown-o"></i></h4>
                                <p class="lead">Find a friend who can help you by finding a ride!</p>
                            </div>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>