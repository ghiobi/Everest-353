<?php $__env->startSection('content'); ?>
    <div class="container section">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <strong>Success!</strong> <?php echo e(Session::get('success')); ?></a>.
            </div>
        <?php endif; ?>
        <div class="row mb-1">
            <div class="col-md-8">
                <div class="media">
                    <a class="media-left" href="/user/<?php echo e($post->poster->id); ?>">
                        <img class="media-object rounded-circle" src="<?php echo e($post->poster->avatarUrl(45)); ?>" width="45">
                    </a>
                    <div class="media-body">
                        <h4 class="media-heading" style="font-size: 14px">Hosted By</h4>
                        <?php echo e($post->poster->fullName()); ?>

                    </div>
                </div>
                <div class="tag-container">
                    <div class="tag tag-default"><?php echo e(($post->postable_type == \App\LocalTrip::class)? 'Local' : 'Long Distance'); ?></div>
                    <div class="tag tag-info"><?php echo e(($post->one_time)? 'One Time' : 'Frequent'); ?></div>
                    <small>Posted <?php echo e($post->created_at->diffForHumans()); ?></small>
                </div>
                <h2><?php echo e($post->name); ?></h2>
                <p class="lead mb-0"><?php echo e($post->description); ?></p>
                <div>
                    Departure: <?php echo e($post->departure_pcode); ?> | Destination: <?php echo e($post->destination_pcode); ?> | Max riders: <?php echo e($post->num_riders); ?>

                </div>
                <?php if($post->postable_type != \App\LocalTrip::class): ?>
                    <div>From: <?php echo e($post->postable->departure_city); ?>, <?php echo e($post->postable->departure_province); ?> | To: <?php echo e($post->postable->destination_city); ?>, <?php echo e($post->postable->destination_province); ?></div>
                <?php endif; ?>
                <?php if(! $post->one_time): ?>
                    <div>
                            <?php echo e($post->postable->displayFrequency()); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <?php if($trip): ?>
                    <div class="card h-100">
                        <div class="card-header">
                            Next trip on <?php echo e($trip->departure_datetime->toFormattedDateString()); ?>

                            at <?php echo e($trip->departure_datetime->format('h:i:s A')); ?>

                            with currently <?php echo e(count($trip->users)); ?> riders.
                        </div>
                        <div class="card-block ">
                            <p class="text-xs-center" style="font-size: 32px">Now for <?php echo e($post->cost()); ?></p>
                            <form action="/trip/<?php echo e($trip->id); ?>/join" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php if(count($errors)> 0): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="alert alert-danger">
                                        <?php echo e($error); ?>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php endif; ?>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="hidden" name="confirm" value="0">
                                        <input type="checkbox" class="form-check-input" name="confirm" value="1">
                                        <small>By Checking this you agree to the terms and the cost of this trip.</small>
                                    </label>
                                </div>
                                <button class="btn btn-info btn-block" type="submit">
                                    Join
                                </button>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="card card-block text-xs-center card h-100">
                        <div class="vcontainer">
                            <div class="valign">
                                <h4 class="card-title">Oh no...</h4>
                                <p class="card-text">Looks like we weren't able to find the next trip! It coult be expired or contact support for help!</p>
                                <a href="/home" class="btn btn-primary">Find another trip!</a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <iframe class="w-100" height="360" src="https://www.google.com/maps/embed/v1/directions?origin=<?php echo e($post->departure_pcode); ?>&destination=<?php echo e($post->destination_pcode); ?>&key=AIzaSyCgfUnLm9_WaYa9hov9l8z4dhVdUuQ6nRg"></iframe>
        </div>
        <div class="card">
            <div class="card-block">
                <?php if(count($post->messages) > 0): ?>
                    <?php $__currentLoopData = $post->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="media" <?php if(! $loop->last && count($post->messages) > 1): ?> style="margin-bottom: 10px;" <?php endif; ?>>
                            <a class="media-left" href="/user/<?php echo e($message->sender->id); ?>">
                                <img class="media-object rounded-circle" src="<?php echo e($message->sender->avatarUrl(45)); ?>" width="45">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading" style="font-size: 14px"><?php echo e($message->sender->fullName()); ?> <small class="text-muted"><?php echo e($message->created_at->diffForHumans()); ?></small></h4>
                                <?php echo e($message->body); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php else: ?>
                    <div class="section text-xs-center">
                        <h3>No messages.</h3>
                        <p class="lead mb-0">Be first to comment!</p>
                    </div>
                <?php endif; ?>
            </div>
            <div class="card-footer">
                <form action="/post/<?php echo e($post->id); ?>/message" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                        <input type="text" class="form-control" name="body">
                        <span class="input-group-btn">
                             <button class="btn btn-outline-info" type="submit">Comment</button>
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>