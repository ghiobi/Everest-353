<?php $__env->startSection('content'); ?>
    <div class="jumbotron">
        <div class="container">
            <h1>Edit a post!</h1>
            <p class="lead">Remember to drive safely.</p>
            <a href="/post/<?php echo e($post->id); ?>">Back to post!</a>
        </div>
    </div>
    <div class="container section">
        <div class="row">
            <div class="col-md-8">
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="/post/<?php echo e($post->id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('patch')); ?>

                    <div class="form-group<?php echo e(($errors->has('name'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__name">Name</label>
                        <input type="text" class="form-control" id="form__name" name="name" value="<?php echo e($post->name); ?>" required minlength="1" maxlength="255">
                        <?php if($errors->has('name')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('name')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('description'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__description">Description</label>
                        <textarea class="form-control" id="form__description" name="description" rows="3" required minlength="1"><?php echo e($post->description); ?></textarea>
                        <?php if($errors->has('description')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('description')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('num_riders'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__num_riders">Number of Riders</label>
                        <input type="number" class="form-control" id="form__num_riders" name="num_riders" value="<?php echo e($post->num_riders); ?>" required min="1">
                        <?php if($errors->has('num_riders')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('num_riders')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e(($errors->has('departure_pcode'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__departure_pcode">Departure Postal Code</label>
                        <input type="text" class="form-control" id="form__departure_pcode" name="departure_pcode" value="<?php echo e($post->departure_pcode); ?>" required pattern="^[A-z]\d[A-z]\s?\d[A-z]\d$">
                        <small class="form-control-feedback">
                            eg. A0A 1A1
                        </small>
                        <?php if($errors->has('departure_pcode')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('departure_pcode')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if($post->postable_type != \App\LocalTrip::class): ?>
                        <div class="row">
                            <div class="col-xs">
                                <div class="form-group">
                                    <label for="">Departure City</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($post->postable->departure_city); ?>">
                                </div>
                            </div>
                            <div class="col-xs">
                                <div class="form-group">
                                    <label for="">Departure Province</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($post->postable->departure_province); ?>">
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="form-group<?php echo e(($errors->has('destination_pcode'))? ' has-danger' : ''); ?>">
                        <label class="form-control-label" for="form__destination_pcode">Destination Postal Code</label>
                        <input type="text" class="form-control" id="form__destination_pcode" name="destination_pcode" value="<?php echo e($post->destination_pcode); ?>" required pattern="^[A-z]\d[A-z]\s?\d[A-z]\d$">
                        <small class="form-control-feedback">
                            eg. A0A 1A1
                        </small>
                        <?php if($errors->has('destination_pcode')): ?>
                            <div class="form-control-feedback">
                                <?php echo e($errors->first('destination_pcode')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if($post->postable_type != \App\LocalTrip::class): ?>
                        <div class="row">
                            <div class="col-xs">
                                <div class="form-group">
                                    <label for="">Destination City</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($post->postable->destination_city); ?>">
                                </div>
                            </div>
                            <div class="col-xs">
                                <div class="form-group">
                                    <label for="">Destination Province</label>
                                    <input type="text" class="form-control" disabled value="<?php echo e($post->postable->destination_province); ?>">
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($post->one_time): ?>
                        <div class="form-group<?php echo e(($errors->has('departure_date'))? ' has-danger' : ''); ?>">
                            <label class="form-control-label" for="form__departure_date">Departure Date</label>
                            <input type="date" class="form-control form-reset" id="form__departure_date" name="departure_date" value="<?php echo e($post->departure_date->format('Y-m-d')); ?>" required>
                            <?php if($errors->has('departure_date')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('departure_date')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <?php if($post->postable_type == \App\LocalTrip::class): ?>
                        <?php if(! $post->one_time): ?>
                            <div class="form-group">
                                <legend>Frequency</legend>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_sun" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_sun" value="1" <?php echo e(($post->postable->frequency[0] == 1)? 'checked': ''); ?>> Sunday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_mon" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_mon" value="1" <?php echo e(($post->postable->frequency[1] == 1)? 'checked': ''); ?>> Monday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_tues" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_tues" value="1" <?php echo e(($post->postable->frequency[2] == 1)? 'checked': ''); ?>> Tuesday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_wed" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_wed" value="1" <?php echo e(($post->postable->frequency[3] == 1)? 'checked': ''); ?>> Wednesday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_thur" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_thur" value="1" <?php echo e(($post->postable->frequency[4] == 1)? 'checked': ''); ?>> Thursday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_fri" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_fri" value="1" <?php echo e(($post->postable->frequency[5] == 1)? 'checked': ''); ?>> Friday
                                </label>
                                <label class="form-check-inline">
                                    <input type="hidden" name="every_sat" value="0">
                                    <input class="form-check-input" type="checkbox" name="every_sat" value="1" <?php echo e(($post->postable->frequency[6] == 1)? 'checked': ''); ?>> Saturday
                                </label>
                            </div>
                        <?php endif; ?>
                        <div class="form-group<?php echo e(($errors->has('time'))? ' has-danger' : ''); ?>">
                            <label for="form__time">Departure Time</label>
                            <input type="time" class="form-control form-reset" id="form__time" name="time" value="<?php echo e($post->postable->departure_time); ?>" required>
                            <?php if($errors->has('time')): ?>
                                <div class="form-control-feedback">
                                    <?php echo e($errors->first('time')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <?php if(! $post->one_time): ?>
                            <div class="form-group">
                                <label for="">Frequency</label>
                                <select class="form-control" name="frequency">
                                    <option value="0" <?php echo e(($post->postable->frequency == 0)? 'selected' : ''); ?>>Every Sunday</option>
                                    <option value="1" <?php echo e(($post->postable->frequency == 1)? 'selected' : ''); ?>>Every Monday</option>
                                    <option value="2" <?php echo e(($post->postable->frequency == 2)? 'selected' : ''); ?>>Every Tuesday</option>
                                    <option value="3" <?php echo e(($post->postable->frequency == 3)? 'selected' : ''); ?>>Every Wednesday</option>
                                    <option value="4" <?php echo e(($post->postable->frequency == 4)? 'selected' : ''); ?>>Every Thursday</option>
                                    <option value="5" <?php echo e(($post->postable->frequency == 5)? 'selected' : ''); ?>>Every Friday</option>
                                    <option value="6" <?php echo e(($post->postable->frequency == 6)? 'selected' : ''); ?>>Every Saturday</option>
                                    <option value="7" <?php echo e(($post->postable->frequency == 7)? 'selected' : ''); ?>>Twice-Monthly</option>
                                    <option value="8" <?php echo e(($post->postable->frequency == 8)? 'selected' : ''); ?>>Monthly</option>
                                </select>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <button class="btn btn-primary" type="submit">Update Post!</button>
                </form>
            </div>
            <div class="col-md-4">
                <h3>Need Help?</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus aut consequuntur dolore eum, illo nihil placeat ratione similique? At delectus deserunt dignissimos dolorum ipsa itaque laborum nihil nobis sed tempore?</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>